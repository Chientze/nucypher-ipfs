name = "nucypher_ipfs"

from .client import Client, connect_ursula